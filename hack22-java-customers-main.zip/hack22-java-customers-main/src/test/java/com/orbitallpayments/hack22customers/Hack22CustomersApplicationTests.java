package com.orbitallpayments.hack22customers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hack22CustomersApplicationTests {

	@Test
	void contextLoads() {
	}

}
