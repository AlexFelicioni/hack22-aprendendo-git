package com.orbitallpayments.hack22customers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hack22CustomersApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hack22CustomersApplication.class, args);
	}

}
